RS Android Project (Starter)

Is ZIP mein Android Studio ke liye starter source project hai.

Is version mein:
- RS home screen
- Hindi speech recognition phone ki speech service ke through
- Hindi text-to-speech response
- WhatsApp/YouTube/Google kholne ke basic commands
- Time batana

Abhi ismein kya NAHI hai:
- Hamesha background mein sunna / 'Hey RS' wake word
- Contacts se naam resolve karke direct call
- Automatic SMS/WhatsApp message bhejna
- Full AI chat integration
- Built APK

Kaise build karein:
1. ZIP extract karein.
2. Android Studio mein extracted RS_Android_Project folder open karein.
3. Gradle sync complete hone dein.
4. Phone ko USB se connect karke Developer options/USB debugging enable karein, ya Build > Build APK(s) choose karein.
5. Microphone permission allow karein.

Note:
- Is project ko compile karne ke liye Android Studio/Android SDK ki zaroorat hai.
- Speech recognition availability phone aur internet/service settings par depend kar sakti hai.
- Call/SMS permissions sensitive hain; user confirmation aur Android permission flow zaroori hai.
