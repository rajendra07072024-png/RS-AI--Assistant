#!/usr/bin/env python3
"""
ASR test harness for a Hindi/English/Hinglish voice assistant.

Scores each engine on what matters: right intent, right contact, right message
body, and latency. Wrong-contact is tracked separately because it is the
dangerous failure.

Usage:
  python runner.py --tests test_set.json --contacts contacts.json --engine transcript
  python runner.py --tests test_set.json --contacts contacts.json --engine whisper --model small

NOTE: normalize / parse_intent / resolve below should be the SAME code your app
uses (move them into a shared module), otherwise you are testing something else.
"""
import argparse
import json
import re
import statistics
import time
import unicodedata
from collections import defaultdict
from difflib import SequenceMatcher
from pathlib import Path

# --------------------------------------------------------------------------
# Shared logic (import this from the app too)
# --------------------------------------------------------------------------

# Crude Devanagari -> Roman for command words only. Contact names are NOT
# transliterated; put Devanagari aliases in contacts.json instead.
# TODO: replace with a real transliteration step once you see real failures.
DEVANAGARI_WORDS = {
    "को": "ko", "से": "se", "फोन": "phone", "कॉल": "call", "लगाओ": "lagao",
    "करो": "karo", "मैसेज": "message", "भेजो": "bhejo", "बोलो": "bolo",
    "की": "ki", "व्हाट्सएप": "whatsapp", "खोलो": "kholo", "आवाज़": "awaaz",
    "आवाज": "awaaz", "बढ़ाओ": "badhao", "हाँ": "haan", "हां": "haan",
    "नहीं": "nahi", "रुको": "ruko", "बात": "baat", "भजन": "bhajan",
    "चलाओ": "chalao", "पढ़ो": "padho", "नया": "naya",
    "मम्मी": "mummy", "मामा": "mama", "राहुल": "rahul", "प्रिया": "priya",
    "रोहन": "rohan", "भेज": "bhej", "दिया": "diya", "दो": "do",
    "खोल": "khol", "समय": "samay", "चाहिए": "chahiye",
}


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFC", text).lower()
    text = re.sub(r"[।.,!?\"']", " ", text)
    words = [DEVANAGARI_WORDS.get(w, w) for w in text.split()]
    return " ".join(words)


RULES = [
    ("voice_message", r"^voice message bhejo (?P<c>.+?)(?: ko)?$"),
    ("send_message", r"^(?P<c>.+?) ko (?:message|msg) (?:bhejo|bhej do|karo)(?: ki)?\s*(?P<b>.*)$"),
    ("send_message", r"^(?P<c>.+?) ko bolo(?: ki)? (?P<b>.+)$"),
    ("call", r"^(?P<c>.+?) ko (?:phone|call) (?:lagao|karo|kar do|laga do)$"),
    ("call", r"^(?P<c>.+?) se baat (?:karni hai|karao|karni)$"),
    ("call", r"^(?P<c>.+?) ko bulao$"),
    ("read_message", r"^(?:naya|latest) message padho$"),
    ("open_app", r"^whatsapp (?:kholo|chalao)$"),
    ("play_media", r"(?:bhajan|gaane|gana|song)s? (?:chalao|lagao)"),
    ("volume", r"awaaz (?:badhao|badha do|kam karo|ghatao)"),
    ("time", r"(?:time|samay) kya"),
    ("hangup", r"(?:call|phone) (?:kaat do|rakh do)"),
    ("answer", r"(?:phone|call) uthao"),
    ("confirm_yes", r"^(?:haan|ha|haan bhejo|bhejo|theek hai)$"),
    ("confirm_no", r"^(?:nahi|nahin|ruko|mat bhejo)$"),
]


def parse_intent(text: str) -> dict:
    t = normalize(text)
    for intent, pattern in RULES:
        m = re.search(pattern, t)
        if m:
            g = m.groupdict()
            return {
                "intent": intent,
                "contact_text": (g.get("c") or "").strip() or None,
                "body": (g.get("b") or "").strip() or None,
            }
    return {"intent": "unknown", "contact_text": None, "body": None}


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a, b).ratio()


def resolve(candidates, contacts, threshold=0.8, margin=0.08):
    """candidates: contact strings heard (top transcript first, then n-best).
    contacts: {name: [normalized aliases]}.
    Returns (status, name) with status in matched / ambiguous / none."""
    for cand in candidates:
        if not cand:
            continue
        cand = normalize(cand)
        scores = sorted(
            ((max(similarity(cand, a) for a in aliases), name)
             for name, aliases in contacts.items()),
            reverse=True,
        )
        if not scores or scores[0][0] < threshold:
            continue
        if len(scores) > 1 and scores[1][0] >= threshold and scores[0][0] - scores[1][0] < margin:
            return "ambiguous", None   # ask the user: "Rahul ya Priya?"
        return "matched", scores[0][1]
    return "none", None


# --------------------------------------------------------------------------
# Engines (one small adapter each; the runner only calls .transcribe)
# --------------------------------------------------------------------------

class Result:
    def __init__(self, text, alternatives=None):
        self.text = text
        self.alternatives = alternatives or []


class TranscriptEngine:
    """Reads the transcript from the test file. For testing the harness itself."""
    name = "transcript"

    def transcribe(self, clip):
        return Result(clip["transcript"], clip.get("alternatives", []))


class WhisperEngine:
    """Local Whisper via faster-whisper (pip install faster-whisper)."""

    def __init__(self, model="small", language="hi"):
        from faster_whisper import WhisperModel
        self.name = f"whisper-{model}"
        self.language = language or None   # try None too: Hinglish often does better with auto-detect
        self.model = WhisperModel(model, compute_type="int8")

    def transcribe(self, clip):
        segments, _ = self.model.transcribe(clip["audio"], language=self.language, beam_size=5)
        return Result(" ".join(s.text.strip() for s in segments))


# --------------------------------------------------------------------------
# Scoring
# --------------------------------------------------------------------------

def score_clip(engine, clip, contacts):
    t0 = time.perf_counter()
    result = engine.transcribe(clip)
    latency_ms = (time.perf_counter() - t0) * 1000

    parsed = parse_intent(result.text)
    row = {
        "id": clip["id"],
        "speaker": clip.get("speaker", "?"),
        "noise": clip.get("noise", "?"),
        "heard": result.text,
        "latency_ms": latency_ms,
        "intent_ok": parsed["intent"] == clip["expected_intent"],
        "got_intent": parsed["intent"],
        "contact": None,
        "body_ok": None,
    }

    expected_contact = clip.get("expected_contact")
    if expected_contact:
        heard = [parsed["contact_text"]] + [parse_intent(a)["contact_text"] for a in result.alternatives]
        status, name = resolve(heard, contacts)
        if status == "matched":
            row["contact"] = "correct" if name == expected_contact else "WRONG"
        elif status == "ambiguous":
            row["contact"] = "clarify"
        else:
            row["contact"] = "not_found"
        row["got_contact"] = name

    expected_body = clip.get("expected_body")
    if expected_body:
        got = normalize(parsed["body"] or "")
        row["body_ok"] = similarity(got, normalize(expected_body)) > 0.85

    return row


def pct(n, d):
    return f"{100 * n / d:.0f}%" if d else "n/a"


def percentile(values, p):
    if not values:
        return 0.0
    values = sorted(values)
    return values[min(len(values) - 1, int(round(p / 100 * (len(values) - 1))))]


def summarize(rows):
    contact_rows = [r for r in rows if r["contact"]]
    body_rows = [r for r in rows if r["body_ok"] is not None]
    lat = [r["latency_ms"] for r in rows]
    return {
        "n": len(rows),
        "intent_ok": sum(r["intent_ok"] for r in rows),
        "contact_n": len(contact_rows),
        "contact_correct": sum(r["contact"] == "correct" for r in contact_rows),
        "contact_clarify": sum(r["contact"] == "clarify" for r in contact_rows),
        "contact_wrong": sum(r["contact"] == "WRONG" for r in contact_rows),
        "contact_not_found": sum(r["contact"] == "not_found" for r in contact_rows),
        "body_n": len(body_rows),
        "body_ok": sum(r["body_ok"] for r in body_rows),
        "p50_ms": percentile(lat, 50),
        "p90_ms": percentile(lat, 90),
    }


def print_report(engine_name, rows, args):
    s = summarize(rows)
    print(f"\n=== {engine_name} ({s['n']} clips) ===")
    print(f"Intent correct : {s['intent_ok']}/{s['n']} ({pct(s['intent_ok'], s['n'])})")
    if s["contact_n"]:
        print(f"Contact        : correct {s['contact_correct']}, clarify {s['contact_clarify']}, "
              f"not found {s['contact_not_found']}, WRONG {s['contact_wrong']}  (of {s['contact_n']})")
    if s["body_n"]:
        print(f"Message body   : {s['body_ok']}/{s['body_n']} ({pct(s['body_ok'], s['body_n'])})")
    print(f"Latency        : p50 {s['p50_ms']:.0f} ms, p90 {s['p90_ms']:.0f} ms")

    # Hard gates first; rank only engines that pass (thresholds are placeholders, set your own).
    wrong_rate = s["contact_wrong"] / s["contact_n"] if s["contact_n"] else 0
    gate_wrong = wrong_rate <= args.max_wrong_contact
    gate_lat = s["p90_ms"] <= args.latency_budget_ms
    print(f"Gates          : wrong-contact <= {args.max_wrong_contact:.0%}: {'PASS' if gate_wrong else 'FAIL'}"
          f" | p90 <= {args.latency_budget_ms} ms: {'PASS' if gate_lat else 'FAIL'}")

    for key in ("speaker", "noise"):
        groups = defaultdict(list)
        for r in rows:
            groups[r[key]].append(r)
        print(f"By {key}:")
        for g, rs in sorted(groups.items()):
            gs = summarize(rs)
            print(f"  {g:<14} intent {pct(gs['intent_ok'], gs['n']):>4} ({gs['n']} clips), "
                  f"wrong-contact {gs['contact_wrong']}")

    failures = [r for r in rows if not r["intent_ok"] or r["contact"] in ("WRONG", "not_found", "clarify")
                or r["body_ok"] is False]
    if failures:
        print("Failures to look at:")
        for r in failures:
            print(f"  {r['id']}: heard '{r['heard']}' -> intent {r['got_intent']}"
                  f"{'' if r['intent_ok'] else ' (WRONG)'}, contact {r['contact']}"
                  f"{'' if r['body_ok'] in (None, True) else ', body wrong'}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tests", required=True)
    ap.add_argument("--contacts", required=True)
    ap.add_argument("--engine", choices=["transcript", "whisper"], default="transcript")
    ap.add_argument("--model", default="small", help="whisper model size")
    ap.add_argument("--language", default="hi", help="whisper language code, or 'auto'")
    ap.add_argument("--max-wrong-contact", type=float, default=0.01)
    ap.add_argument("--latency-budget-ms", type=int, default=1500)
    ap.add_argument("--out", help="write per-clip results to this JSON file")
    args = ap.parse_args()

    clips = json.loads(Path(args.tests).read_text(encoding="utf-8"))
    raw = json.loads(Path(args.contacts).read_text(encoding="utf-8"))
    contacts = {name: [normalize(a) for a in aliases] for name, aliases in raw.items()}

    if args.engine == "transcript":
        engine = TranscriptEngine()
    else:
        missing_audio = [c.get("id", "?") for c in clips if not c.get("audio") or not Path(c["audio"]).is_file()]
        if missing_audio:
            ap.error(
                "Whisper engine needs real audio files and an 'audio' path in each test item. "
                "Missing audio for test IDs: " + ", ".join(missing_audio)
                + ". Use --engine transcript to test the command parser with the supplied text-only dataset."
            )
        engine = WhisperEngine(args.model, None if args.language == "auto" else args.language)

    rows = [score_clip(engine, c, contacts) for c in clips]
    print_report(engine.name, rows, args)

    if args.out:
        Path(args.out).write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
