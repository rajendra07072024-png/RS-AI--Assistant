# RS Voice Assistant — starter test bundle

This bundle contains the three reviewed files:
- `runner.py`: tests command parsing, contact matching, message-body matching, and latency.
- `contacts.json`: contact names and spoken aliases.
- `test_set.json`: 13 sample text-transcript test cases.

## Run the supplied text tests
Requires Python 3.9+; no extra package is needed for transcript mode.

```bash
python runner.py --tests test_set.json --contacts contacts.json --engine transcript
```

## Important limitations
- These files are a **test harness**, not an Android APK and not a complete voice assistant.
- The supplied tests contain text transcripts, not audio recordings. Whisper mode requires actual audio files and an `audio` path for each test item.
- To make RS place calls on Android, a separate Android app implementation is required, with microphone/contacts/call permissions and appropriate user confirmation. This Python test script does not place calls.
- For safety, the Android app should speak back the matched contact and ask for confirmation before dialing, especially when an alias such as `beta` matches more than one person.
- Do not add real phone numbers to shared files unless you intend to store them there.
