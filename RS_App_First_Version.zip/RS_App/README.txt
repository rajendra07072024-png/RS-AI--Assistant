RS Voice Assistant — शुरुआती मोबाइल ऐप

यह एक installable web app (PWA) का शुरुआती संस्करण है, APK नहीं।
इसमें:
- हिंदी/English/Hinglish voice input (समर्थित Android Chrome में)
- कॉन्टैक्ट नाम और नंबर सेव करना (इसी ब्राउज़र में)
- कॉल के लिए फोन ऐप खोलना (उपयोगकर्ता को कॉल शुरू करना होगा)
- SMS लिखने के लिए मैसेज ऐप खोलना
- WhatsApp और YouTube खोलने के शॉर्टकट

इसे चलाने का आसान तरीका:
1. इस ZIP को extract करें।
2. इन फाइलों को किसी HTTPS static hosting पर डालना होगा; सीधे file:// से microphone/PWA हर जगह काम नहीं करेंगे।
3. Android Chrome में hosted index.html खोलें।
4. Chrome menu ⋮ > Add to Home screen / Install app चुनें।
5. माइक्रोफ़ोन अनुमति दें और Contacts में नाम/नंबर सेव करें।

सीमाएँ:
- यह Android APK नहीं है और अभी “Hey RS” wake word हमेशा सुनने की सुविधा नहीं देता।
- Browser voice recognition के लिए इंटरनेट/समर्थित browser आवश्यक हो सकता है।
- Calls/SMS स्वतः नहीं भेजे जाते; Android फोन/मैसेज ऐप खुलता है और यूज़र को कार्रवाई करनी होती है।
- कॉन्टैक्ट नंबर इसी ब्राउज़र के local storage में रहते हैं। डिवाइस/ब्राउज़र डेटा साफ करने पर हट सकते हैं।
